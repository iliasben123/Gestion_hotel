package application;

import javafx.application.Application;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

public class SecondPage extends Application {

    @Override
    public void start(Stage primaryStage) {
        primaryStage.setTitle("Menu");

        StackPane root = new StackPane();

        Image backgroundImage = new Image("file:C:/Users/hp/Desktop/hotel2.jpg");
        ImageView backgroundImageView = new ImageView(backgroundImage);
        backgroundImageView.setFitWidth(800);
        backgroundImageView.setFitHeight(600);
        root.getChildren().add(backgroundImageView);

        VBox menuLayout = new VBox(10);
        Button employeesButton = new Button("Employees");
        Button clientsButton = new Button("Clients");
        Button reservationsButton = new Button("Reservations");
        Button viewPlanningButton = new Button("View Planning");

        employeesButton.setStyle("-fx-background-color: #4CAF50; -fx-text-fill: white; -fx-font-size: 16px; -fx-pref-width: 200px; -fx-pref-height: 40px; -fx-border-radius: 5px; -fx-background-radius: 5px; -fx-cursor: hand;");
        clientsButton.setStyle("-fx-background-color: #4CAF50; -fx-text-fill: white; -fx-font-size: 16px; -fx-pref-width: 200px; -fx-pref-height: 40px; -fx-border-radius: 5px; -fx-background-radius: 5px; -fx-cursor: hand;");
        reservationsButton.setStyle("-fx-background-color: #4CAF50; -fx-text-fill: white; -fx-font-size: 16px; -fx-pref-width: 200px; -fx-pref-height: 40px; -fx-border-radius: 5px; -fx-background-radius: 5px; -fx-cursor: hand;");
        viewPlanningButton.setStyle("-fx-background-color: #4CAF50; -fx-text-fill: white; -fx-font-size: 16px; -fx-pref-width: 200px; -fx-pref-height: 40px; -fx-border-radius: 5px; -fx-background-radius: 5px; -fx-cursor: hand;");

        employeesButton.setOnMouseEntered(e -> employeesButton.setStyle("-fx-background-color: #45a049;"));
        employeesButton.setOnMouseExited(e -> employeesButton.setStyle("-fx-background-color: #4CAF50;"));
        employeesButton.setOnMousePressed(e -> employeesButton.setStyle("-fx-background-color: #0a802b;"));

        clientsButton.setOnMouseEntered(e -> clientsButton.setStyle("-fx-background-color: #45a049;"));
        clientsButton.setOnMouseExited(e -> clientsButton.setStyle("-fx-background-color: #4CAF50;"));
        clientsButton.setOnMousePressed(e -> clientsButton.setStyle("-fx-background-color: #0a802b;"));

        reservationsButton.setOnMouseEntered(e -> reservationsButton.setStyle("-fx-background-color: #45a049;"));
        reservationsButton.setOnMouseExited(e -> reservationsButton.setStyle("-fx-background-color: #4CAF50;"));
        reservationsButton.setOnMousePressed(e -> reservationsButton.setStyle("-fx-background-color: #0a802b;"));

        viewPlanningButton.setOnMouseEntered(e -> viewPlanningButton.setStyle("-fx-background-color: #45a049;"));
        viewPlanningButton.setOnMouseExited(e -> viewPlanningButton.setStyle("-fx-background-color: #4CAF50;"));
        viewPlanningButton.setOnMousePressed(e -> viewPlanningButton.setStyle("-fx-background-color: #0a802b;"));

        employeesButton.setOnAction(e -> {
            EmployeesPage employeesPage = new EmployeesPage();
            employeesPage.start(new Stage());
        });

        clientsButton.setOnAction(e -> {
            ClientPage clientPage = new ClientPage();
            clientPage.start(new Stage());
        });

        reservationsButton.setOnAction(e -> {
            ReservationPage reservationPage = new ReservationPage();
            reservationPage.start(new Stage());
        });

        viewPlanningButton.setOnAction(e -> {
            ViewPlanningPage viewPlanningPage = new ViewPlanningPage();
            viewPlanningPage.start(new Stage());
        });

        menuLayout.setAlignment(Pos.CENTER);
        menuLayout.getChildren().addAll(employeesButton, clientsButton, reservationsButton, viewPlanningButton);

        root.getChildren().add(menuLayout);

        Scene menuScene = new Scene(root, 800, 600);
        primaryStage.setScene(menuScene);
        primaryStage.show();
    }

    private void showAlert(String title, String message) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }

    
}
