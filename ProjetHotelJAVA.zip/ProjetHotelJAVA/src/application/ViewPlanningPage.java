package application;

import javafx.application.Application;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

import java.sql.*;

public class ViewPlanningPage extends Application {

    private TableView<Planning> table = new TableView<>();
    private TextField firstNameField = new TextField();
    private TextField secondNameField = new TextField();
    private TextField professionField = new TextField();
    private TextField dateDebutField = new TextField();
    private TextField dateFinField = new TextField();
    private TextField gmailField = new TextField();

    private static final String DB_URL = "jdbc:mysql://localhost:3306/taha1";
    private static final String DB_USER = "root";
    private static final String DB_PASSWORD = "taha123";

    @Override
    public void start(Stage primaryStage) {
        primaryStage.setTitle("View Planning");

        TableColumn<Planning, String> firstNameCol = new TableColumn<>("First Name");
        TableColumn<Planning, String> secondNameCol = new TableColumn<>("Second Name");
        TableColumn<Planning, String> professionCol = new TableColumn<>("Profession");
        TableColumn<Planning, String> dateDebutCol = new TableColumn<>("Date Debut");
        TableColumn<Planning, String> dateFinCol = new TableColumn<>("Date Fin");
        TableColumn<Planning, String> gmailCol = new TableColumn<>("Gmail");

        firstNameCol.setCellValueFactory(cellData -> cellData.getValue().firstNameProperty());
        secondNameCol.setCellValueFactory(cellData -> cellData.getValue().secondNameProperty());
        professionCol.setCellValueFactory(cellData -> cellData.getValue().professionProperty());
        dateDebutCol.setCellValueFactory(cellData -> cellData.getValue().dateDebutProperty());
        dateFinCol.setCellValueFactory(cellData -> cellData.getValue().dateFinProperty());
        gmailCol.setCellValueFactory(cellData -> cellData.getValue().gmailProperty());

        table.getColumns().addAll(firstNameCol, secondNameCol, professionCol, dateDebutCol, dateFinCol, gmailCol);

        Button rechercherButton = new Button("Rechercher");
        rechercherButton.setOnAction(e -> searchByName());

        Button ajouterButton = new Button("Ajouter");
        ajouterButton.setOnAction(e -> addPlanningToDB());

        Button supprimerButton = new Button("Supprimer");
        supprimerButton.setOnAction(e -> deletePlanningFromDB());

        HBox inputBox = new HBox(10);
        inputBox.getChildren().addAll(firstNameField, secondNameField, professionField, dateDebutField, dateFinField, gmailField, rechercherButton, ajouterButton, supprimerButton);

        VBox layout = new VBox(10);
        layout.setPadding(new Insets(20));
        layout.setAlignment(Pos.TOP_LEFT);
        layout.getChildren().addAll(table, inputBox);

        Scene scene = new Scene(layout, 800, 600);
        primaryStage.setScene(scene);
        primaryStage.show();

        loadPlanning();
    }

    private void loadPlanning() {
        table.getItems().clear();
        try (Connection conn = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);
             ResultSet rs = conn.createStatement().executeQuery("SELECT * FROM groupeemp")) {

            while (rs.next()) {
                Planning planning = new Planning();
                planning.setFirstName(rs.getString("EmpFirstName"));
                planning.setSecondName(rs.getString("EmpSecondName"));
                planning.setProfession(rs.getString("EmpProfession"));
                planning.setDateDebut(rs.getString("EmpDateD"));
                planning.setDateFin(rs.getString("EmpDateF"));
                planning.setGmail(rs.getString("EmpGmail"));
                table.getItems().add(planning);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private void searchByName() {
        String firstName = firstNameField.getText();

        table.getItems().clear();

        try (Connection conn = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD)) {
            String query = "SELECT * FROM groupeemp WHERE EmpFirstName LIKE ?";
            PreparedStatement pstmt = conn.prepareStatement(query);
            pstmt.setString(1, "%" + firstName + "%");
            ResultSet rs = pstmt.executeQuery();

            while (rs.next()) {
                Planning planning = new Planning();
                planning.setFirstName(rs.getString("EmpFirstName"));
                planning.setSecondName(rs.getString("EmpSecondName"));
                planning.setProfession(rs.getString("EmpProfession"));
                planning.setDateDebut(rs.getString("EmpDateD"));
                planning.setDateFin(rs.getString("EmpDateF"));
                planning.setGmail(rs.getString("EmpGmail"));
                table.getItems().add(planning);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private void addPlanningToDB() {
        String firstName = firstNameField.getText();
        String secondName = secondNameField.getText();
        String profession = professionField.getText();
        String dateDebut = dateDebutField.getText();
        String dateFin = dateFinField.getText();
        String gmail = gmailField.getText();

        try (Connection conn = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD)) {
            String query = "INSERT INTO groupeemp (EmpFirstName, EmpSecondName, EmpProfession, EmpDateD, EmpDateF, EmpGmail) VALUES (?, ?, ?, ?, ?, ?)";
            PreparedStatement pstmt = conn.prepareStatement(query);
            pstmt.setString(1, firstName);
            pstmt.setString(2, secondName);
            pstmt.setString(3, profession);
            pstmt.setString(4, dateDebut);
            pstmt.setString(5, dateFin);
            pstmt.setString(6, gmail);
            pstmt.executeUpdate();
            loadPlanning(); // Rafraîchir la table après l'insertion
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private void deletePlanningFromDB() {
        Planning selectedPlanning = table.getSelectionModel().getSelectedItem();
        if (selectedPlanning != null) {
            try (Connection conn = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD)) {
                String query = "DELETE FROM groupeemp WHERE EmpFirstName = ? AND EmpSecondName = ? AND EmpProfession = ? AND EmpDateD = ? AND EmpDateF = ? AND EmpGmail = ?";
                PreparedStatement pstmt = conn.prepareStatement(query);
                pstmt.setString(1, selectedPlanning.getFirstName());
                pstmt.setString(2, selectedPlanning.getSecondName());
                pstmt.setString(3, selectedPlanning.getProfession());
                pstmt.setString(4, selectedPlanning.getDateDebut());
                pstmt.setString(5, selectedPlanning.getDateFin());
                pstmt.setString(6, selectedPlanning.getGmail());
                pstmt.executeUpdate();
                table.getItems().remove(selectedPlanning); // Supprimer de la TableView
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }

    public static class Planning {
        private final javafx.beans.property.SimpleStringProperty firstName = new javafx.beans.property.SimpleStringProperty();
        private final javafx.beans.property.SimpleStringProperty secondName = new javafx.beans.property.SimpleStringProperty();
        private final javafx.beans.property.SimpleStringProperty profession = new javafx.beans.property.SimpleStringProperty();
        private final javafx.beans.property.SimpleStringProperty dateDebut = new javafx.beans.property.SimpleStringProperty();
        private final javafx.beans.property.SimpleStringProperty dateFin = new javafx.beans.property.SimpleStringProperty();
        private final javafx.beans.property.SimpleStringProperty gmail = new javafx.beans.property.SimpleStringProperty();

        public javafx.beans.property.StringProperty firstNameProperty() {
            return firstName;
        }

        public String getFirstName() {
            return firstName.get();
        }

        public void setFirstName(String fName) {
            firstName.set(fName);
        }

        public javafx.beans.property.StringProperty secondNameProperty() {
            return secondName;
        }

        public String getSecondName() {
            return secondName.get();
        }

        public void setSecondName(String sName) {
            secondName.set(sName);
        }

        public javafx.beans.property.StringProperty professionProperty() {
            return profession;
        }

        public String getProfession() {
            return profession.get();
        }

        public void setProfession(String prof) {
            profession.set(prof);
        }

        public javafx.beans.property.StringProperty dateDebutProperty() {
            return dateDebut;
        }

        public String getDateDebut() {
            return dateDebut.get();
        }

        public void setDateDebut(String start) {
            dateDebut.set(start);
        }

        public javafx.beans.property.StringProperty dateFinProperty() {
            return dateFin;
        }

        public String getDateFin() {
            return dateFin.get();
        }

        public void setDateFin(String end) {
            dateFin.set(end);
        }

        public javafx.beans.property.StringProperty gmailProperty() {
            return gmail;
        }

        public String getGmail() {
            return gmail.get();
        }

        public void setGmail(String mail) {
            gmail.set(mail);
        }
    }
}


