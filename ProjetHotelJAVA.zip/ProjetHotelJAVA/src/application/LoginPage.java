package application;

import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.stage.Stage;

public class LoginPage {
    private static final String ADMIN_PASSWORD = "ktim";

    public static void showLogin(Stage primaryStage) {
        primaryStage.setTitle("Login");

        StackPane root = new StackPane();

        Image backgroundImage = new Image("file:C:/Users/hp/Desktop/hotel4.jpg");

        ImageView backgroundImageView = new ImageView(backgroundImage);
        backgroundImageView.setFitWidth(800);
        backgroundImageView.setFitHeight(600);

        VBox loginLayout = new VBox(10);
        loginLayout.setPadding(new Insets(20));
        loginLayout.setAlignment(Pos.CENTER_LEFT); 

        Label usernameLabel = new Label("Username:");
        usernameLabel.setTextFill(Color.BLACK);
        TextField usernameInput = new TextField();

        Label passwordLabel = new Label("Password:");
        passwordLabel.setTextFill(Color.BLACK);
        PasswordField passwordInput = new PasswordField();

        Button loginButton = new Button("Login");
        loginButton.setOnAction(e -> {
            String username = usernameInput.getText();
            String password = passwordInput.getText();

            if (login(username, password)) {
                openSecondPage(primaryStage);
            } else {
                showAlert("Login Failed", "Invalid username or password.");
            }
        });

        loginLayout.getChildren().addAll(usernameLabel, usernameInput, passwordLabel, passwordInput, loginButton);

        root.getChildren().addAll(backgroundImageView, loginLayout);

        Scene loginScene = new Scene(root, 800, 600);
        primaryStage.setScene(loginScene);
        primaryStage.show();
    }

    private static boolean login(String username, String password) {
        return username.equals("EMSI") && password.equals(ADMIN_PASSWORD);
    }

    private static void openSecondPage(Stage primaryStage) {
        Stage secondStage = new Stage();
        SecondPage secondPage = new SecondPage();
        secondPage.start(secondStage);
        primaryStage.close();
    }

    private static void showAlert(String title, String message) {
        Alert alert = new Alert(Alert.AlertType.ERROR);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }
}



