package application;

import javafx.application.Application;
import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class EmployeesPage extends Application {

    private static final String DB_URL = "jdbc:mysql://localhost:3306/taha1";
    private static final String DB_USER = "root";
    private static final String DB_PASSWORD = "taha123";

    @Override
    public void start(Stage primaryStage) {
        primaryStage.setTitle("Employees Page");

        TableView<Employee> table = new TableView<>();

        TableColumn<Employee, String> firstNameCol = new TableColumn<>("First Name");
        TableColumn<Employee, String> lastNameCol = new TableColumn<>("Last Name");
        TableColumn<Employee, String> professionCol = new TableColumn<>("Profession");
        TableColumn<Employee, String> emailCol = new TableColumn<>("Email");
        TableColumn<Employee, String> phoneNumCol = new TableColumn<>("Phone Number");

        firstNameCol.setCellValueFactory(cellData -> cellData.getValue().firstNameProperty());
        lastNameCol.setCellValueFactory(cellData -> cellData.getValue().lastNameProperty());
        professionCol.setCellValueFactory(cellData -> cellData.getValue().professionProperty());
        emailCol.setCellValueFactory(cellData -> cellData.getValue().emailProperty());
        phoneNumCol.setCellValueFactory(cellData -> cellData.getValue().phoneNumberProperty());

        table.getColumns().addAll(firstNameCol, lastNameCol, professionCol, emailCol, phoneNumCol);

        TextField firstNameField = new TextField();
        firstNameField.setPromptText("First Name");
        TextField lastNameField = new TextField();
        lastNameField.setPromptText("Last Name");
        TextField professionField = new TextField();
        professionField.setPromptText("Profession");
        TextField emailField = new TextField();
        emailField.setPromptText("Email");
        TextField phoneNumberField = new TextField();
        phoneNumberField.setPromptText("Phone Number");

        Button addButton = new Button("Add");
        addButton.setOnAction(e -> {
            Employee newEmployee = new Employee();
            newEmployee.setFirstName(firstNameField.getText());
            newEmployee.setLastName(lastNameField.getText());
            newEmployee.setProfession(professionField.getText());
            newEmployee.setEmail(emailField.getText());
            newEmployee.setPhoneNumber(phoneNumberField.getText());

            insertEmployee(newEmployee);

            table.getItems().add(newEmployee);
        });

        Button deleteButton = new Button("Delete");
        deleteButton.setOnAction(e -> {
            Employee selectedEmployee = table.getSelectionModel().getSelectedItem();
            if (selectedEmployee != null) {
                deleteEmployee(selectedEmployee);
                table.getItems().remove(selectedEmployee);
            }
        });

        HBox inputBox = new HBox(10);
        inputBox.getChildren().addAll(
                firstNameField, lastNameField, professionField, emailField, phoneNumberField, addButton, deleteButton);

        VBox layout = new VBox(10);
        layout.getChildren().addAll(table, inputBox);

        Scene scene = new Scene(layout, 600, 400);
        primaryStage.setScene(scene);
        primaryStage.show();

        loadEmployees(table);
    }

    private void loadEmployees(TableView<Employee> table) {
        try {
            Connection conn = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);
            Statement stmt = conn.createStatement();
            ResultSet rs = stmt.executeQuery("SELECT * FROM employees");

            while (rs.next()) {
                Employee employee = new Employee();
                employee.setFirstName(rs.getString("FirstName"));
                employee.setLastName(rs.getString("LastName"));
                employee.setProfession(rs.getString("Profession"));
                employee.setEmail(rs.getString("Email"));
                employee.setPhoneNumber(rs.getString("PhoneNumber"));
                table.getItems().add(employee);
            }

            conn.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private void insertEmployee(Employee employee) {
        try {
            Connection conn = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);
            String query = "INSERT INTO employees (FirstName, LastName, Profession, Email, PhoneNumber) VALUES ( ?, ?, ?, ?, ?)";
            PreparedStatement pstmt = conn.prepareStatement(query);
            pstmt.setString(1, employee.getFirstName());
            pstmt.setString(2, employee.getLastName());
            pstmt.setString(3, employee.getProfession());
            pstmt.setString(4, employee.getEmail());
            pstmt.setString(5, employee.getPhoneNumber());
            pstmt.executeUpdate();

            conn.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private void deleteEmployee(Employee employee) {
        try {
            Connection conn = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);
            String query = "DELETE FROM employees WHERE FirstName = ? AND LastName = ?";
            PreparedStatement pstmt = conn.prepareStatement(query);
            pstmt.setString(1, employee.getFirstName());
            pstmt.setString(2, employee.getLastName());
            pstmt.executeUpdate();

            conn.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public static class Employee {
        private final StringProperty firstName = new SimpleStringProperty();
        private final StringProperty lastName = new SimpleStringProperty();
        private final StringProperty profession = new SimpleStringProperty();
        private final StringProperty email = new SimpleStringProperty();
        private final StringProperty phoneNumber = new SimpleStringProperty();

        public String getFirstName() {
            return firstName.get();
        }

        public void setFirstName(String firstNameValue) {
            firstName.set(firstNameValue);
        }

        public StringProperty firstNameProperty() {
            return firstName;
        }

        public String getLastName() {
            return lastName.get();
        }

        public void setLastName(String lastNameValue) {
            lastName.set(lastNameValue);
        }

        public StringProperty lastNameProperty() {
            return lastName;
        }

        public String getProfession() {
            return profession.get();
        }

        public void setProfession(String professionValue) {
            profession.set(professionValue);
        }

        public StringProperty professionProperty() {
            return profession;
        }

        public String getEmail() {
            return email.get();
        }

        public void setEmail(String emailValue) {
            email.set(emailValue);
        }

        public StringProperty emailProperty() {
            return email;
        }

        public String getPhoneNumber() {
            return phoneNumber.get();
        }

        public void setPhoneNumber(String phoneNumberValue) {
            phoneNumber.set(phoneNumberValue);
        }

        public StringProperty phoneNumberProperty() {
            return phoneNumber;
        }
    }

   
}
