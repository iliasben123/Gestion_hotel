package application;

import javafx.application.Application;
import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class ClientPage extends Application {

    private TableView<Client> table = new TableView<>();

    private static final String DB_URL = "jdbc:mysql://localhost:3306/taha1";
    private static final String DB_USER = "root";
    private static final String DB_PASSWORD = "taha123";

    @Override
    public void start(Stage primaryStage) {
        primaryStage.setTitle("Clients Page");

        TableColumn<Client, String> firstNameCol = new TableColumn<>("First Name");
        TableColumn<Client, String> lastNameCol = new TableColumn<>("Last Name");
        TableColumn<Client, String> emailCol = new TableColumn<>("Email");
        TableColumn<Client, String> phoneNumCol = new TableColumn<>("Phone Number");
        TableColumn<Client, String> cinClientCol = new TableColumn<>("CIN Client");

        firstNameCol.setCellValueFactory(cellData -> cellData.getValue().firstName1Property());
        lastNameCol.setCellValueFactory(cellData -> cellData.getValue().lastName1Property());
        emailCol.setCellValueFactory(cellData -> cellData.getValue().email1Property());
        phoneNumCol.setCellValueFactory(cellData -> cellData.getValue().phoneNumber1Property());
        cinClientCol.setCellValueFactory(cellData -> cellData.getValue().cinClientProperty());

        table.getColumns().addAll(firstNameCol, lastNameCol, emailCol, phoneNumCol, cinClientCol);

        TextField firstNameField = new TextField();
        firstNameField.setPromptText("First Name");
        TextField lastNameField = new TextField();
        lastNameField.setPromptText("Last Name");
        TextField emailField = new TextField();
        emailField.setPromptText("Email");
        TextField phoneNumberField = new TextField();
        phoneNumberField.setPromptText("Phone Number");
        TextField cinClientField = new TextField();
        cinClientField.setPromptText("CIN Client");

        Button addButton = new Button("Add");
        addButton.setOnAction(e -> {
            Client newClient = new Client();
            newClient.setFirstName1(firstNameField.getText());
            newClient.setLastName1(lastNameField.getText());
            newClient.setEmail1(emailField.getText());
            newClient.setPhoneNumber1(phoneNumberField.getText());
            newClient.setCinClient(cinClientField.getText());

            insertClient(newClient);

            table.getItems().add(newClient);
        });

        Button deleteButton = new Button("Delete");
        deleteButton.setOnAction(e -> {
            Client selectedClient = table.getSelectionModel().getSelectedItem();
            if (selectedClient != null) {
                deleteClient(selectedClient);
                table.getItems().remove(selectedClient);
            }
        });

        Button updateButton = new Button("Update");
        updateButton.setOnAction(e -> {
            Client selectedClient = table.getSelectionModel().getSelectedItem();
            if (selectedClient != null) {
                selectedClient.setFirstName1(firstNameField.getText());
                selectedClient.setLastName1(lastNameField.getText());
                selectedClient.setEmail1(emailField.getText());
                selectedClient.setPhoneNumber1(phoneNumberField.getText());
                selectedClient.setCinClient(cinClientField.getText());
                updateClient(selectedClient);
                loadClients(); 
            }
        });

        Button searchButton = new Button("Search by CIN");
        searchButton.setOnAction(e -> {
            String cin = cinClientField.getText();
            searchClientByCIN(cin);
        });

        HBox inputBox = new HBox(10);
        inputBox.getChildren().addAll(
                firstNameField, lastNameField, emailField, phoneNumberField, cinClientField, addButton, deleteButton, updateButton, searchButton);

        VBox layout = new VBox(10);
        layout.getChildren().addAll(table, inputBox);

        Scene scene = new Scene(layout, 600, 400);
        primaryStage.setScene(scene);
        primaryStage.show();

        loadClients();
    }

    private void loadClients() {
        table.getItems().clear();
        try (Connection conn = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);
             ResultSet rs = conn.createStatement().executeQuery("SELECT * FROM client")) {

            while (rs.next()) {
                Client client = new Client();
                client.setFirstName1(rs.getString("firstName1"));
                client.setLastName1(rs.getString("lastName1"));
                client.setEmail1(rs.getString("email"));
                client.setPhoneNumber1(rs.getString("phonenumber1"));
                client.setCinClient(rs.getString("CinClient"));
                table.getItems().add(client);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private void insertClient(Client client) {
        try (Connection conn = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD)) {
            String query = "INSERT INTO client (firstName1, lastName1, email, phonenumber1, CinClient) VALUES (?, ?, ?, ?, ?)";
            PreparedStatement pstmt = conn.prepareStatement(query);
            pstmt.setString(1, client.getFirstName1());
            pstmt.setString(2, client.getLastName1());
            pstmt.setString(3, client.getEmail1());
            pstmt.setString(4, client.getPhoneNumber1());
            pstmt.setString(5, client.getCinClient());
            pstmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private void deleteClient(Client client) {
        try (Connection conn = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD)) {
            String query = "DELETE FROM client WHERE firstName1 = ? AND lastName1 = ?";
            PreparedStatement pstmt = conn.prepareStatement(query);
            pstmt.setString(1, client.getFirstName1());
            pstmt.setString(2, client.getLastName1());
            pstmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private void updateClient(Client client) {
        try (Connection conn = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD)) {
            String query = "UPDATE client SET email = ?, phonenumber1 = ?, CinClient = ? WHERE firstName1 = ? AND lastName1 = ?";
            PreparedStatement pstmt = conn.prepareStatement(query);
            pstmt.setString(1, client.getEmail1());
            pstmt.setString(2, client.getPhoneNumber1());
            pstmt.setString(3, client.getCinClient());
            pstmt.setString(4, client.getFirstName1());
            pstmt.setString(5, client.getLastName1());
            pstmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private void searchClientByCIN(String cin) {
        try (Connection conn = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD)) {
            String query = "SELECT * FROM client WHERE CinClient = ?";
            PreparedStatement pstmt = conn.prepareStatement(query);
            pstmt.setString(1, cin);
            ResultSet rs = pstmt.executeQuery();

            table.getItems().clear();
            while (rs.next()) {
                Client client = new Client();
                client.setFirstName1(rs.getString("firstName1"));
                client.setLastName1(rs.getString("lastName1"));
                client.setEmail1(rs.getString("email"));
                client.setPhoneNumber1(rs.getString("phonenumber1"));
                client.setCinClient(rs.getString("CinClient"));
                table.getItems().add(client);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public static class Client {
        private final StringProperty firstName1 = new SimpleStringProperty();
        private final StringProperty lastName1 = new SimpleStringProperty();
        private final StringProperty email1 = new SimpleStringProperty();
        private final StringProperty phoneNumber1 = new SimpleStringProperty();
        private final StringProperty cinClient = new SimpleStringProperty();

        public String getFirstName1() {
            return firstName1.get();
        }

        public void setFirstName1(String firstName1) {
            this.firstName1.set(firstName1);
        }

        public StringProperty firstName1Property() {
            return firstName1;
        }

        public String getLastName1() {
            return lastName1.get();
        }

        public void setLastName1(String lastName1) {
            this.lastName1.set(lastName1);
        }

        public StringProperty lastName1Property() {
            return lastName1;
        }

        public String getEmail1() {
            return email1.get();
        }

        public void setEmail1(String email1) {
            this.email1.set(email1);
        }

        public StringProperty email1Property() {
            return email1;
        }

        public String getPhoneNumber1() {
            return phoneNumber1.get();
        }

        public void setPhoneNumber1(String phoneNumber1) {
            this.phoneNumber1.set(phoneNumber1);
        }

        public StringProperty phoneNumber1Property() {
            return phoneNumber1;
        }

        public String getCinClient() {
            return cinClient.get();
        }

        public void setCinClient(String cinClient) {
            this.cinClient.set(cinClient);
        }

        public StringProperty cinClientProperty() {
            return cinClient;
        }
    }
}
