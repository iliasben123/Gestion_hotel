package application;
import javafx.application.Application;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;
import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class ReservationPage extends Application {

    @Override
    public void start(Stage primaryStage) {
        primaryStage.setTitle("Reservations Page");

        TableView<Reservation> table = new TableView<>();
        TableColumn<Reservation, String> cinCol = new TableColumn<>("CIN client");
        TableColumn<Reservation, String> nameCol = new TableColumn<>("Name");
        TableColumn<Reservation, String> typeChambreCol = new TableColumn<>("Type Chambre");
        TableColumn<Reservation, String> checkInCol = new TableColumn<>("Check-in");
        TableColumn<Reservation, String> checkOutCol = new TableColumn<>("Check-out");

        cinCol.setCellValueFactory(cellData -> cellData.getValue().cinProperty());
        nameCol.setCellValueFactory(cellData -> cellData.getValue().nameProperty());
        typeChambreCol.setCellValueFactory(cellData -> cellData.getValue().typeChambreProperty());
        checkInCol.setCellValueFactory(cellData -> cellData.getValue().checkInProperty());
        checkOutCol.setCellValueFactory(cellData -> cellData.getValue().checkOutProperty());

        table.getColumns().addAll(cinCol, nameCol, typeChambreCol, checkInCol, checkOutCol);

        Button deleteReservationButton = new Button("Delete Reservation");
        Button updateReservationButton = new Button("Update Reservation");

        HBox buttonBox = new HBox(10);
        buttonBox.getChildren().addAll(deleteReservationButton, updateReservationButton);

        VBox layout = new VBox(10);
        layout.setPadding(new Insets(20));
        layout.setAlignment(Pos.TOP_LEFT);
        layout.getChildren().addAll(table, buttonBox);

        Scene scene = new Scene(layout, 600, 400);
        primaryStage.setScene(scene);
        primaryStage.show();

        
        try {
            Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/taha1", "root", "taha123");

            Statement stmt = conn.createStatement();
            ResultSet rs = stmt.executeQuery("SELECT * FROM reservation");

            while (rs.next()) {
                Reservation reservation = new Reservation();
                reservation.setCin(rs.getString("cinclient"));
                reservation.setName(rs.getString("name"));
                reservation.setTypeChambre(rs.getString("typechambre"));
                reservation.setCheckIn(rs.getString("checkIn"));
                reservation.setCheckOut(rs.getString("checkOut"));
                table.getItems().add(reservation);
            }

            conn.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public class Reservation {
        private final StringProperty cin = new SimpleStringProperty();
        private final StringProperty name = new SimpleStringProperty();
        private final StringProperty typeChambre = new SimpleStringProperty();
        private final StringProperty checkIn = new SimpleStringProperty();
        private final StringProperty checkOut = new SimpleStringProperty();

        
        public String getCin() {
            return cin.get();
        }

        public void setCin(String cinValue) {
            cin.set(cinValue);
        }

        public StringProperty cinProperty() {
            return cin;
        }

        public String getName() {
            return name.get();
        }

        public void setName(String nameValue) {
            name.set(nameValue);
        }

        public StringProperty nameProperty() {
            return name;
        }

        
        public String getTypeChambre() {
            return typeChambre.get();
        }

        public void setTypeChambre(String typeChambreValue) {
            typeChambre.set(typeChambreValue);
        }

        public StringProperty typeChambreProperty() {
            return typeChambre;
        }

       
        public String getCheckIn() {
            return checkIn.get();
        }

        public void setCheckIn(String checkInValue) {
            checkIn.set(checkInValue);
        }

        public StringProperty checkInProperty() {
            return checkIn;
        }

      
        public String getCheckOut() {
            return checkOut.get();
        }

        public void setCheckOut(String checkOutValue) {
            checkOut.set(checkOutValue);
        }

        public StringProperty checkOutProperty() {
            return checkOut;
        }
    } 
} 